package jdonut.tools;

public class DMath {
	/**
	 * Adds arg1 onto arg2.
	 * @param arg1
	 * @param arg2 
	 */
	public static int add(int arg1, int arg2) {
		return arg1 + arg2;
	}
	/**
	 * Subtracts arg1 from arg2.
	 * @param arg1
	 * @param arg2
	 */
	public static int subtract(int arg1, int arg2) {
		return arg1 - arg2;
	}
	/**
	 * Divides arg1 from arg2.
	 * @param arg1
	 * @param arg2
	 */
	public static int divide(int arg1, int arg2) {
		return arg1 / arg2;
	}
	/**
	 * multiplies arg1 to arg2.
	 * @param arg1
	 * @param arg2
	 *
	 */
	public static int multiply(int arg1, int arg2) {
		return arg1 * arg2;
	}
	
}
