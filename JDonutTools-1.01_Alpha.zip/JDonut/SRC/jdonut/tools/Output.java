package jdonut.tools;

public class Output {
	/**
	 * Prints arg1 on a new line.
	 */
	public static void println(String arg1) {
		System.out.println(arg1);
	}
	/**
	 * Prints arg1 on a new line.
	 */
	public static void println(int arg1) {
		System.out.println(arg1);
	}
	/**
	 * Prints arg1 on a new line.
	 */
	public static void println(boolean arg1) {
		System.out.println(arg1);
	}
	
	/**
	 * prints arg1.
	 */
	public static void print(String arg1) {
		System.out.print(arg1);
	}
	/**
	 * Prints arg1.
	 */
	public static void print(int arg1) {
		System.out.print(arg1);
	}
	/**
	 * Prints arg1.
	 */
	public static void print(boolean arg1) {
		System.out.print(arg1);
	}
	
}
