package jdonut;

import jdonut.tools.DMath;
import jdonut.tools.Output;
@SuppressWarnings("unused") 
class JDonut {
	private static DMath math;
    private static Output ouput;
    
    
	private static String version = "1.00.1";
	public static void main(String[] args){
		System.out.println("**************************************");
		System.out.println("               JDONUT                 ");
		System.out.println("**************************************");
		System.out.println("           VERSION:" + " " + version);
		System.out.println("**************************************");
	}
	
	
	
	
}
